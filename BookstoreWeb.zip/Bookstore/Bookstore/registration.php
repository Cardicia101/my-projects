<?php

    include('DBConn.php');
    $output = NULL;
    $fname = $lname = $email = $stnum = $pass =  $cpass = "";

//Submit button code to register user
    if(isset($_POST['submit']))
    {
    
        $fname = $_POST['fname'];
		$lname = $_POST['lname'];
        $email = $_POST['email'];
		$stnum = $_POST['stnum'];
        $pass = $_POST['pass']; 
        $cpass = $_POST['cpass'];
        
		//pattern considered for strong password
        $pattern = '/^(?=.*[!@#$%^&*-?])(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{4,20}$/';
		
        $query = "SELECT * FROM tblusers WHERE email = '$email' OR stnum = '$stnum'";
    
        $checkUserExsists = mysqli_query($conn,$query);
        
        if(empty($fname) || empty($lname) || empty($email) || empty($stnum)|| empty($pass) || empty($cpass))
        {
            $output = "Fields cannot be empty";
        }
        elseif(filter_var($email, FILTER_VALIDATE_EMAIL) != true)
        {
            $output = "Invalid Email address";
        }
        elseif(mysqli_num_rows($checkUserExsists) == 1)
        {
            $output = "User already exsists";
        }

        elseif($pass != $cpass)
        {
            $output = "Passwords do not match";
        }

		elseif(!preg_match($pattern, $pass))
		{
			$output = "Password is not strong enough";
		}
        else
        {
			
            $pass = md5($pass);
            $query = "INSERT INTO tblusers (fname,lname,email,stnum,password,vstatus) VALUES ('$fname','$lname','$email','$stnum','$pass',1)";
            $insertUser = mysqli_query($conn,$query);
            if ($insertUser == true) 
            {
                $output = "Your registration is now pending for approval";
				$fname = $lname = $email = $stnum = NULL;
            
			}
        }
    
    
    }
	
?>

<!DOCTYPE html>
<htm>
    <head>
	  <link rel ="stylesheet" href ="Css.css">
        <title></title>
		  <style>

    
    ul.menu {
      list-style-type: none;
      margin: 0;
      padding: 0;
      background-color:purple ;
    }
    
    ul.menu li {
      display: inline-block;
    }
    
    ul.menu li a {
      display: block;
      padding: 10px 60px;
      text-decoration: none;
	  font-size: 22px;
      color: white;
    }
    
    ul.menu li a:hover {
      background-color: #ddd;
    }
	
	ul.h1 {text-align: center;}
	ul.h1 {background-color: white}
	
	
	ul.p{text-align: center}
	ul.p{background-color:orange}
	/*for h2*/
	h2{text-align: center}
	/*for footer*/
	ul.ff
	{ 
      background-color: green;
       padding: 10px;
       text-align: center;
     color: white;
    }

		</style>
</head>

    

<body background="img/backround1.jpg" link="#000">
    <center>
        <br>
        <br>
        <br>
		 <ul class="menu">
    <li><a href="login.php">Login</a></li>
	<li><a href="Admin.php">Admin</a></li>
    <li><a href="userBookViewing.php">Books</a></li>
    <li><a href="registration.php">Register</a></li>
	
  </ul>
  
    
    <form method="post">
        <table>
            <tr>
                <td>Firstname :</td>
                <td> <input type="text" name = "fname" minlength="3" maxlength="20" value = "<?php echo $fname; ?>" ></td>
            </tr>
			<tr>
                <td>Surname :</td>
                <td> <input type="text" name = "lname" minlength="3" maxlength="20" value = "<?php echo $lname; ?>" ></td>
            </tr>
            <tr>
                <td>Email :</td>
                <td> <input type="email" name = "email"  value = "<?php echo $email; ?>" ></td>
            </tr>
			<tr>
                <td>STNumber :</td>
                <td> <input type="text" name = "stnum"  value = "<?php echo $stnum; ?>" ></td>
            </tr>
            <tr>
                <td>Password :</td>
                <td> <input type="password" name = "pass"></td>
            </tr>
            <tr>
                <td>Confirm Password :</td>
                <td> <input type="password" name = "cpass"></td>
            </tr>
                        <tr>
                <td></td>
                <td><input type="submit" name="submit" value="Register"></td>
				
            </tr>
			
			
        </table>
        
    
    
    </form>
    <?php
    echo "<br>";
    echo $output;
    ?>
        
        <p>Already have an Account : Click here to <a href="login.php">Login</a></p> 
		<p>Click here to Login as: <a href="Admin.php">Admin</a></p>
        </center>
    
</body>


</htm>