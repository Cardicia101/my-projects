<?php
   
	
	include "DBConn.php";
	include 'createTable.php'; 
	
    $output = NULL;
	

if(isset($_POST['back']))
    {
    
      header("location:login.php");
	}

  if(isset($_POST['login']))
    {
      $_SESSION['email'] = $_POST['email'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $hpass = md5($password);

        $query = "SELECT email, password FROM tblusers WHERE email = '$email' AND password = '$hpass'";
        
        $result = mysqli_query($conn,$query);

        $row = mysqli_fetch_array($result);
		
	  if(empty($email))
        {
			echo "Enter username as ST********@rcconnect.edu.za";
            $output = "Enter username as ST********@rcconnect.edu.za";
        }

        else 
        { 
             if($row["usertype"]=="user" ) 
             {
				 echo "You are not an admin";
                 
             }
            else 
            {
                header("location:Approval_page.php");
            }
        
        }
	}

?>
<html>

 <head>
   

 <link rel ="stylesheet" href ="Css.css">
  <style>

 
    ul.menu {
      list-style-type: none;
      margin: 0;
      padding: 0;
      background-color: purple;
    }
    
    ul.menu li {
      display: inline-block;
    }
    
    ul.menu li a {
      display: block;
      padding: 10px 60px;
      text-decoration: none;
	  font-size: 22px;
      color: white;
    }
    
    ul.menu li a:hover {
      background-color: #ddd;
    }
	
	ul.h1 {text-align: center;}
	ul.h1 {background-color: white}
	
	ul.p{text-align: center}
	ul.p{background-color:orange}
	
	h2{text-align: center}
	
	ul.ff
	{ 
      background-color: green;
       padding: 10px;
       text-align: center;
     color: white;
    }

		</style>
 </head>


 
 <body background="img/background.jpg" link="#000">
 <h1>Admin Login</h1>
 
  <ul class="menu">
    <li><a href="login.php">Login</a></li>
	<li><a href="Admin.php">Admin</a></li>
    <li><a href="userBookViewing.php">Books</a></li>
    <li><a href="registration.php">Register</a></li>
	
  </ul>
  
 
 
<form action="" method="post"> 

  Username:<input type="email" name ="email"><br/><br/>
  
  Password:<input type="password" name ="password"><br/><br/><br/><br/>
  
  <input type="submit" name ="login" value="Login">
  <input type="submit" name="back" value="Back">
  
  </form>
  
 </body>
</html>
