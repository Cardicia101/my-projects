<?php

//Database connection code
$servername = "localhost";
$user = "root";
$password = "";
$db = "bookstore";                                         

$conn = mysqli_connect($servername,$user,$password);
                           
//Connecting to the database                                        
if($conn == TRUE){
	//echo"Database Connected";
}
else{                                                                                         
	echo"An error occured".mysqli_connect_error();
}

//Creating a database if it doesn't exist
$selectDB = mysqli_select_db($conn,$db);
	

		if (!$selectDB) {

		$sql = "CREATE DATABASE ".$db."";
		
		mysqli_query($conn, $sql); 
		
		
		//echo "<br>Database ".$db." succesfully created<br>";

		} else {
			
		   //echo "<br>Database ".$db." already exsist<br>";
			
		}


?>