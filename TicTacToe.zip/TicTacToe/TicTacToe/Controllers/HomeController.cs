using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using TicTacToe.Models;

namespace TicTacToe.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        // Index action will display the player name input page
        public IActionResult Index()
        {
            return View();
        }

        // Action for starting a new game
        [HttpPost]
        public IActionResult StartGame(string player1, string player2)
        {
            // Pass the player names to the view (or redirect to another action)
            ViewBag.Player1 = player1;
            ViewBag.Player2 = player2;
            return View("Game"); // Redirect to the game page after players enter their names
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}

