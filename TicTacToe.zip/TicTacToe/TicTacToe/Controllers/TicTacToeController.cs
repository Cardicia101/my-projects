﻿using Microsoft.AspNetCore.Mvc;
using TicTacToe.Models;

namespace TicTacToe.Controllers
{
    public class TicTacToeController : Controller
    {
        private static TicTacToeModel _game = new TicTacToeModel();

        public IActionResult Index()
        {
            return View(_game);
        }

        [HttpPost]
        public IActionResult MakeMove(int row, int col)
        {
            _game.MakeMove(row, col);
            return RedirectToAction("Index");
        }

        public IActionResult ResetGame()
        {
            _game = new TicTacToeModel();
            return RedirectToAction("Index");
        }
    }
}

