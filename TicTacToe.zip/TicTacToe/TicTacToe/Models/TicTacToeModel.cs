﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using System;
using TicTacToe.Models;

namespace TicTacToe.Models
{
    public class TicTacToeModel
    {
        public char[,] Board { get; set; }
        public char CurrentPlayer { get; set; }
        public string Message { get; set; }
        public bool GameOver { get; set; }

        public TicTacToeModel()
        {
            // Initialize the game board
            Board = new char[3, 3];
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    Board[i, j] = ' ';  // Empty space
            CurrentPlayer = 'X';  // Player X starts
            GameOver = false;
            Message = "Player X's turn";
        }

        public void MakeMove(int row, int col)
        {
            if (Board[row, col] == ' ' && !GameOver)
            {
                Board[row, col] = CurrentPlayer;

                if (CheckWin())
                {
                    GameOver = true;
                    Message = $"Player {CurrentPlayer} wins!";
                }
                else if (IsBoardFull())
                {
                    GameOver = true;
                    Message = "It's a draw!";
                }
                else
                {
                    CurrentPlayer = (CurrentPlayer == 'X') ? 'O' : 'X'; // Switch players
                    Message = $"Player {CurrentPlayer}'s turn";
                }
            }
        }

        private bool IsBoardFull()
        {
            foreach (var spot in Board)
            {
                if (spot == ' ')
                    return false;
            }
            return true;
        }

        private bool CheckWin()
        {
            // Check rows, columns, and diagonals for a win
            for (int i = 0; i < 3; i++)
            {
                if (Board[i, 0] == CurrentPlayer && Board[i, 1] == CurrentPlayer && Board[i, 2] == CurrentPlayer)
                    return true;
                if (Board[0, i] == CurrentPlayer && Board[1, i] == CurrentPlayer && Board[2, i] == CurrentPlayer)
                    return true;
            }

            if (Board[0, 0] == CurrentPlayer && Board[1, 1] == CurrentPlayer && Board[2, 2] == CurrentPlayer)
                return true;
            if (Board[0, 2] == CurrentPlayer && Board[1, 1] == CurrentPlayer && Board[2, 0] == CurrentPlayer)
                return true;

            return false;
        }
    }
}



