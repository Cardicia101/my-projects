﻿let board = ["", "", "", "", "", "", "", "", ""];
let currentPlayer = "X";
let player1 = "";
let player2 = "";
let isGameOver = false;

// Handle making a move and updating the turn message
function makeMove(index) {
    if (!isGameOver && board[index] === "") {
        board[index] = currentPlayer;
        document.getElementById(`cell-${index}`).innerText = currentPlayer;

        if (checkWin()) {
            showWinMessage(`${getPlayerName(currentPlayer)} wins!`);
        } else if (board.every(cell => cell !== "")) {
            showWinMessage("It's a draw!");
        } else {
            currentPlayer = currentPlayer === "X" ? "O" : "X"; // Switch player
            updateTurnMessage(); // Update message box for next player
        }
    }
}

// Start the game after entering player names
function startGame() {
    player1 = document.getElementById("player1-name").value;
    player2 = document.getElementById("player2-name").value;

    if (player1 === "" || player2 === "") {
        alert("Please enter both player names.");
        return;
    }

    // Hide player name input and show the game grid
    document.getElementById("player-names-section").style.display = "none";
    document.getElementById("game-section").style.display = "block";

    // Display initial turn message
    updateTurnMessage();
}

// Update the message box to show whose turn it is
function updateTurnMessage() {
    const messageBox = document.getElementById("message-box");
    messageBox.innerText = `It's ${getPlayerName(currentPlayer)}'s turn`;
}

// Get player name based on the current player (X or O)
function getPlayerName(player) {
    return player === "X" ? player1 : player2;
}

// Show win message and medal
function showWinMessage(message) {
    document.getElementById("win-text").innerText = message;
    document.getElementById("win-message").style.display = "block";
    document.getElementById("win-medal").style.display = "inline"; // Show medal image
    isGameOver = true;
}

// Reset the game without changing player names
function resetGame() {
    board = ["", "", "", "", "", "", "", "", ""];
    currentPlayer = "X";
    isGameOver = false;
    document.getElementById("win-message").style.display = "none"; // Hide win message
    document.getElementById("win-medal").style.display = "none";   // Hide medal image

    // Reset the grid cells
    for (let i = 0; i < 9; i++) {
        document.getElementById(`cell-${i}`).innerText = "";
    }

    // Update the turn message
    updateTurnMessage();
}

// Start a new game by resetting everything, including player names
function newGame() {
    // Reset the game grid
    resetGame();

    // Hide the game section and show the player name input section again
    document.getElementById("game-section").style.display = "none";
    document.getElementById("player-names-section").style.display = "block";

    // Clear player name inputs
    document.getElementById("player1-name").value = "";
    document.getElementById("player2-name").value = "";

    // Reset internal variables
    player1 = "";
    player2 = "";
}

// Check for a win condition (rows, columns, diagonals)
function checkWin() {
    const winConditions = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
        [0, 4, 8], [2, 4, 6]             // Diagonals
    ];

    return winConditions.some(condition => {
        const [a, b, c] = condition;
        return board[a] && board[a] === board[b] && board[a] === board[c];
    });
}

